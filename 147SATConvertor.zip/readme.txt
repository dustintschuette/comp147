Dustin Schuette
University of the Pacific
3 color graph adjacency list to Mini SAT converter

How to Use:
Paste the adjacency text file into input.txt or simply rename it. The resulting boolean formula will be written to output.txt

The bash script will make the program and then run it.
