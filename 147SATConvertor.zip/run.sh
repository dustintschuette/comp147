#!/bin/sh
make
./scanner input.txt output.txt
